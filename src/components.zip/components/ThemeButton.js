import React from 'react'
import { useTheme } from './ThemeProvider.js'
export default function ThemeButton() {
const { theme, toggleTheme } = useTheme();
return (
<button onClick={toggleTheme}>
: {theme === "light" ? " " : " "}
</button>
)
};