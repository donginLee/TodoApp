// import React,{useEffect,useState} from 'react';
import React, {useEffect, useState} from 'react';


export default function BlinkComponent({text}){
    const [showText, setShowText] = useState(true);
    showText = true

    useEffect(
        ()=>{
            const intervalID = setInterval(()=>{setShowText(!showText);},1000);
            return ()=>{ console.log(intervalID); clearInterval(intervalID);}}
    ,[showText]);
    return (
        <div>
            {showText ? text : null}
        </div>
    )
}