// ChildComponentA.js
import React, { useEffect,useRef } from 'react';

export default function ChildComponentA({check }){
  const ref = useRef();
  useEffect(()=>{ref.current.focus();},[check]);
  return (<input ref={ref}></input>)
};
