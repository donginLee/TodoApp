import React,{useCallback} from 'react';
export default function InputColorTodo({setInputColor}){
    const changeColor=(e)=>{
        setInputColor(e.target.style.backgroundColor);
    }
    let bgColor = useCallback((color) => {
        if (color === 'r') return 'lightpink';
        else if (color === 'g') return 'lightgreen';
        else if (color === 'b') return 'lightblue';
        else if (color === 'bl') return 'lightgrey';
        else return 'cyan';
    }, []);
    return(
        <div style={{width:"100%",display:"flex",margin:"20px",justifyContent:'space-around'}}>
            <div onClick={changeColor} style={{width:"60px", height:"60px",borderRadius:"50%",textAlign:"center",alignContent:"center",backgroundColor:bgColor('r')}}></div>
            <div onClick={changeColor} style={{width:"60px", height:"60px",borderRadius:"50%",textAlign:"center",alignContent:"center",backgroundColor:bgColor('g')}}></div>
            <div onClick={changeColor} style={{width:"60px", height:"60px",borderRadius:"50%",textAlign:"center",alignContent:"center",backgroundColor:bgColor('b')}}></div>
            <div onClick={changeColor} style={{width:"60px", height:"60px",borderRadius:"50%",textAlign:"center",alignContent:"center",backgroundColor:bgColor('bl')}}></div>
        </div>
    )
};