import React, { useState, useCallback, useEffect,useContext} from 'react';
import InputColorTodo from './InputColorTodo.js';
import InputTextTodo from './InputTextTodo.js';
import TodoList from './TodoList.js';
import { TodoContext } from './TodoProvider.js';
import { useTodos,useSetTodos } from './Context.js';
export default function ToDoApp() {
    const [inputcolor, setInputColor] = useState('lightpink');
    const [inputtext, setInputText] = useState('');
    const [searchtext, setSearchText] = useState('');
//    console.log(TodoContext);
    // const {toDos, setTodos} = useContext(TodoContext);
    const toDos=useTodos();
    const setTodos=useSetTodos();
    const [id, setId] = useState(0);

    // useEffect(() => {
    //     const savedTodos = window.sessionStorage.getItem('todos');
    //     console.log("첫");
    //     if (savedTodos) {
    //         setTodos(JSON.parse(savedTodos));
    //     }
    //     return ()=>{console.log("ㅂㅇ");}
    // }, []);

   

    // useEffect(()=>{sessionStorage.setItem('todos',JSON.stringify(toDos));},[toDos]);
    useEffect(()=>{onSearch();},[searchtext]);
    const onClick = useCallback(() => {
        if(!inputtext) return;
        const updatedTodos = toDos.map(item => ({
            ...item,
            searched: false
        }));
        setTodos(prevTodos => [
            ...updatedTodos,
            { 'color': inputcolor, 'text': inputtext, 'id': id, 'onEdit':false,'searched': false }
        ]);
        setInputColor('lightpink');
        setInputText('');
        setId(prevId => prevId + 1); // 이전 상태에서 1을 증가하여 새로운 ID를 할당
    }, [inputcolor, inputtext, toDos, id]);

    useEffect(()=>{
        window.sessionStorage.setItem('todos', JSON.stringify(toDos));
        console.log("들어감",window.sessionStorage.getItem('todos'));
    },[toDos]);

    const startEdit= useCallback(
        (idx) => {
            console.log(toDos);
            console.log(idx);
            const updatedTodos = toDos.map(item => {
                if (item.id === idx) {
                    return { ...item, onEdit: true }; 
                } else {
                    return item;
                }
            });
            setTodos(updatedTodos);
        }, [toDos]
    );
    const finishEdit= useCallback(
        (idx,content) => {
            console.log(toDos);
            console.log(idx);
            const updatedTodos = toDos.map(item => {
                if (item.id === idx) {
                    return { ...item, text:content, onEdit: false }; 
                } else {
                    return item;
                }
            });
            setTodos(updatedTodos);
        }, [toDos]
    );
    const onSearch = useCallback(() => {
        const updatedTodos = toDos.map(item => ({
            ...item,
            searched: item.text.startsWith(searchtext)
        }));

        setTodos(updatedTodos);
    }, [toDos, searchtext]);

    const onDelete = useCallback(
        (idx) => {
            console.log(idx);
            console.log('삭제됨');
            const updatedTodos = toDos.filter(item => item.id !== idx);
            setTodos(updatedTodos);
        }, [toDos]
    );
    return (
        <div style={{ backgroundColor: "rgba(90,140,250)", width: "100vw", height: "100vh", display: "flex", justifyContent: "center", top: "0px" }}>
            <div style={{width: "80vw", display: "flex", paddingTop:"50px",justifyContent:"flex-start",flexDirection:"column" }}>
                <InputTextTodo style={{ width: "100%" }} color={"none"} setInputText={setSearchText} text="안눌러도됨" onClick={()=>{alert('누르지마세요');}}></InputTextTodo>
                <InputTextTodo style={{ width: "100%" }} color={inputcolor} setInputText={setInputText} onClick={onClick} text="submit"></InputTextTodo>
                <InputColorTodo setInputColor={setInputColor}></InputColorTodo>
                {toDos.map((item) => {
                return <TodoList style={{margin:"5px"}} key={item.id} id={item.id} onEdit={item.onEdit} startEdit={startEdit} finishEdit={finishEdit} color={item.color} text={item.text} searched={item.searched} onClick={() => item.onEdit?null:onDelete(item.id)}></TodoList>
})}
            </div>
        </div>
    );
}

