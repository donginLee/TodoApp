import React from "react";
function HelloWorld({url,des}){
    return(
        <div>
            <img src={url}/>
            <p>{des}</p>
        </div>
    )
}
export default HelloWorld;