import React, {useState} from "react";
import ChildComponentA from "./ChildComponentA.js";
import ChildComponentB from "./ChildComponentB.js";


function ParentComponent(){
    const [check, setCheck]=useState(true); 
    const changeCheck=()=>{setCheck(!check);};
    console.log(check,setCheck);
    
    return(
        <div>
            {/* <CountComponent a ={3}></CountComponent> */}
            <ChildComponentA check={check}></ChildComponentA>
            <ChildComponentB check={check} changeCheck={changeCheck}></ChildComponentB>
        </div>
    )


}
export default ParentComponent;