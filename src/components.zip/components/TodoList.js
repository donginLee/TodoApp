import React, { useMemo, useRef, useState } from 'react';
import Edit from './Edit.js';
// import InputTextTodo from './InputTextTodo.js';

export default function TodoList({ id,onEdit,color, startEdit,finishEdit,text ,searched, onClick}) {

    const ref=useRef();
    const [content,setContent]=useState("");
    return (
        <div style={{display:"flex",marginTop:"10px"}}>
        <div onClick={onClick} style={{display:"flex",width:"100%",height:"30px",backgroundColor: color,boxSizing:"border-box", width:"100%",alignContent:"center",textAlign:"center",border:searched?"3px solid red":"none"}} >
        {onEdit?

         <div style={{alignContent:"center", width:"90%", justifyContent:"center"}}><input ref={ref}onInput={(e)=>{setContent(e.target.value)}}style={{width:"90%",height:"20px"}}></input></div>
        :
            <div style={{marginLeft:"5px",alignContent:"center"}}>
                <p>{text}</p>
            </div>
        }
        
        </div>
        <Edit id={id} content={content}onClick={onEdit?finishEdit:startEdit} onEdit={onEdit}></Edit>
        </div>
    );
}
