import React, { useContext, useCallback } from "react";
import { TodoContext } from "./TodoProvider";

export const useTodos = () => {
    const { toDos } = useContext(TodoContext);
    return toDos;
};

export const useSetTodos = () => {
    const { setTodos } = useContext(TodoContext);
    return setTodos;
};