import React from "react";
// import { Button } from "react-bootstrap"; // Importing Button component from react-bootstrap library
// import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
// import { faEdit } from "@fortawesome/free-solid-svg-icons";

export default function Edit({id, content,onClick,onEdit}) {
    return (
        <div onClick={(onEdit)=>{onClick(id,content);}} style={{margin:"auto 0 auto 10px",width:"30px",height:"30px",color:onEdit?"red":"white",fontSize:"10px",borderRadius:"50%",background:"lightGrey",textAlign:"center",alignContent:"center"}}>
            {onEdit?"완료":"수정"}
        </div>
    );
}