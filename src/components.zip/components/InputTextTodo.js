import React, { useRef,useMemo} from 'react';
export default function InputTextTodo({ color, setInputText, onClick, text }) {
    const inputRef = useRef();
    const handleChange = (event) => {
        setInputText(event.target.value);
    };

    const handleButtonClick = () => {
        onClick();
        inputRef.current.value = "";
        inputRef.current.focus();
    };

    return (
        <div style={{ display: "flex" }}>
            <input style={{ width: "80%", backgroundColor: color}} type="text" onChange={handleChange} ref={inputRef} />
            <button style={{ width: "20%", display: "flex", justifyContent: "center" }} onClick={handleButtonClick}>{text}</button>
        </div>
    );
}
