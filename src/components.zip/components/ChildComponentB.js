// ChildComponentB.js
import React,{useState}from 'react';

export default function ChildComponentB({check,changeCheck}){

    const run=()=>{changeCheck(!check)};
  return (<div onClick= {run}>Child Compoent B</div>);
};